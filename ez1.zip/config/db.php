<?php
/**
 * @package        EzMvcPHP
 * @author         quezier
 * @email          33590896@qq.com
 */
return array(
    'dbType'=>'mysql',
    'dbHost'=>'127.0.0.1',
    'dbName'=>'ezmvcphp',
    'dbUserName'=>'root',
    'dbPwd'=>'root',
    'recordsPerPage'=>10,//每页记录数，用于分页
);