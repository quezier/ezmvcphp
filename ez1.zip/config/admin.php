<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
return array(
    //公共文件路径
    'public_page' => PROJECT_ROOT . DIR_SP . 'app' . DIR_SP . 'Admin' . DIR_SP . 'View' . DIR_SP . 'Public' . DIR_SP,
    'TREE_LEVEL'=>2//登录成功后，需要保持几级菜单到session
);

