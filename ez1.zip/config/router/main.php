<?php
/**
 * @package        EzMvcPHP
 * @author         quezier
 * @email          33590896@qq.com
 */
return array(
    'router',
    'test',
    'admin',
    'admin/admin_main',
    'admin/admin_admin',
    'admin/admin_first_level',
    'admin/admin_article_info',
    'admin/admin_article_type',
);


