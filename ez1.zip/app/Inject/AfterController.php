<?php
namespace App\Inject;

/**
 * @package        EzMvcPHP
 * @author         quezier
 * @email          33590896@qq.com
 */
class AfterController
{
    function action()
    {
        //echo 'after controller';
    }
}