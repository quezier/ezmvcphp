<footer class="blog-footer">
    <p>湘依信息：<a href="http://bbs.xy-hn.com/">http://bbs.xy-hn.com/</a>  邮箱: 33590896@qq.com Q Q:33590896</p>
    <p><a href="http://webscan.360.cn/index/checkwebsite/url/bbs.xy-hn.com" name="9e20db03102c44d28be20f95431898cf" >360网站安全检测平台</a></p>
    <p>
        <a href="#">回到顶部</a>
    </p>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo JS_HOST;?>/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
